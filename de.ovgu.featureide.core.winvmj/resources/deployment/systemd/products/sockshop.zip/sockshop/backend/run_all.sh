#!/bin/bash
source ~/.zshrc  

cleanup() {
    echo "Exiting script..."
    pkill -P $$
    exit 1
}

trap cleanup SIGINT

echo "Enter the path to the frontend directory: "
read -p "Enter the path to the frontend directory: " frontend_dir

echo "SELECT 'CREATE DATABASE webshop_product_eshoponcontainers' WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'webshop_product_eshoponcontainers') \gexec" | psql "postgresql://postgres:300100@localhost"
for file in sql/*.sql; do
    psql -a -f "$file" "postgresql://postgres:300100@localhost/webshop_product_eshoponcontainers"
done

java -cp webshop.product.eshoponcontainers --module-path webshop.product.eshoponcontainers -m webshop.product.eshoponcontainers &

cd $frontend_dir && {
    npm install && {
        npm run json:server &
        npm run start &
    }
}

wait